package third;

public class Pawn extends Piece{
	
	public boolean isLegalMove(Box a, Box b) {
		if (a.getX() == b.getX() && (a.getY() + 1 == b.getY()))
			return true;
		return false;
	}
}
