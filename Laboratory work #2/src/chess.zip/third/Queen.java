package third;

public class Queen {
	
	public boolean isLegalMove(Box a, Box b) {
		if (a.getX() == b.getX() || a.getY() == b.getY() || 
				(Math.abs(a.getX() - b.getX()) == Math.abs(a.getY() - b.getY())))
			return true;
		return false;
	}
}
