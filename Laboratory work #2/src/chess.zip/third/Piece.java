package third;

public class Piece {
	
	private boolean killed;
	
	public boolean canMove(Box a, Box b) {
		return false;
	}
	
	public boolean isWhite() {
		return false;
	}
	
	public boolean isKilled() {
		return false;
	}
}
