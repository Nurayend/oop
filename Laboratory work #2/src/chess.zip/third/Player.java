package third;

public class Player {

}
