package third;

public class Rook extends Piece{
	
	public boolean isLegalMove(Box a, Box b) {
		if (a.getX() == b.getX() || a.getY() == b.getY())
			return true;
		return false;
	}
}
