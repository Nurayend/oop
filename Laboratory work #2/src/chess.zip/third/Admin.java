package third;

public class Admin {

}
