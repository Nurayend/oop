package third;

public class King extends Piece{
	
	public boolean isLegalMove(Box a, Box b) {
		if ((Math.abs(a.getX() - b.getX()) == 1 || Math.abs(a.getY() - b.getY()) == 1) && 
				((Math.abs(a.getX() - b.getX())) == 1 && (Math.abs(a.getY() - b.getY())) == 1))
			return true;
		return false;
	}
}
